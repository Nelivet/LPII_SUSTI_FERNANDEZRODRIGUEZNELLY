package com.susti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.susti.entity.Usuario;
import com.susti.service.UsuarioService;

@Controller
public class UsuarioController {
	@Autowired
	private UsuarioService service;
	
	@GetMapping("/login")
	public String login(Model model) {
		return "login";
	}
	
	@PostMapping("/login")
	public String login(@RequestParam(name = "usuario") String usuario, @RequestParam(name = "contrasena") String contrasena, Model model) {
		boolean user = service.login(usuario, contrasena);
		
		return user ? "menu" : "login";
	}
}