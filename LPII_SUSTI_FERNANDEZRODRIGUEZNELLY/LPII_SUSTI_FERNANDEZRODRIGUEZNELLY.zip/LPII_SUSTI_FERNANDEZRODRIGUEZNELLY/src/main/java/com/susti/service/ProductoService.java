package com.susti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.susti.dao.ProductoDAO;
import com.susti.entity.Producto;

@Service
public class ProductoService {
	@Autowired
	private ProductoDAO repo;
	
	public Producto registrar(Producto bean) {
		return repo.save(bean);
	}
	
	public List<Producto> listar() {
		return repo.findAll();
	}
}