package com.susti.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.susti.entity.Usuario;

@Repository
public interface UsuarioDao extends JpaRepository<Usuario, Integer> {
	public Usuario findByUsuarioAndContrasena(String usuario, String contrasena);
}