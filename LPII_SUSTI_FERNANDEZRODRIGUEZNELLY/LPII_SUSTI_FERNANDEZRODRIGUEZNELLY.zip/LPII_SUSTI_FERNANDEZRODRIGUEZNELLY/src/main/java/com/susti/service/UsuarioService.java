package com.susti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.susti.dao.UsuarioDao;
import com.susti.entity.Usuario;

@Service
public class UsuarioService {
	@Autowired
	private UsuarioDao repo;
	
	public boolean login(String usuario, String contrasena) {
		Usuario user = repo.findByUsuarioAndContrasena(usuario, contrasena);
		System.out.println(user.toString());
		return user != null;
	}
}