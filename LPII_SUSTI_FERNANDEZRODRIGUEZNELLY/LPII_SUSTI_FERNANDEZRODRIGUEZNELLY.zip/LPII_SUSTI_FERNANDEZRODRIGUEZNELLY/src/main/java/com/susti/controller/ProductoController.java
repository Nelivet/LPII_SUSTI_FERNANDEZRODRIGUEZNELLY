package com.susti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.susti.entity.Producto;
import com.susti.service.ProductoService;

@Controller
public class ProductoController {
	@Autowired
	private ProductoService service;
	
	@GetMapping("/producto")
	public String guardarProducto(Model model) {
		List<Producto> productos = service.listar();
		model.addAttribute("producto", new Producto());
		model.addAttribute("lstProductos", productos);
		return "Producto";
	}
	
	@PostMapping("/registrar")
	public String guardarProducto(@ModelAttribute Producto producto) {
		service.registrar(producto);
		
		return "redirect:/producto";
	}
}