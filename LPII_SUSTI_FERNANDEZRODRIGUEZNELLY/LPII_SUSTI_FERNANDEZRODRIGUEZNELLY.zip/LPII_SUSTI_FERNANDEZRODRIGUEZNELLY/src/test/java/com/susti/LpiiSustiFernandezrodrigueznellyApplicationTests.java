package com.susti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LpiiSustiFernandezrodrigueznellyApplicationTests {

	@Test
	void contextLoads() {
	}

}
